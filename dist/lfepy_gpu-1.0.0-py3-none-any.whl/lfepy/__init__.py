# __init__.py in the main package
__version__ = '1.0.0'
__author__ = ["Dr. Prof. Khalid M. Hosny", "M.Sc. Mahmoud A. Mohamed"]
__license__ = 'MIT'

# Example of a package-wide configuration
DEBUG = False